npm install
npm start