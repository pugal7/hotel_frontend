import React from "react";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "bootstrap/dist/css/bootstrap.css";
import "./App.css";

import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import EditHotel from "./components/edit-hotel.component";
import HotelList from "./components/hotel-listing.component";
import CreateHotel from "./components/create-hotel.component";
import Login from "./components/login.component";

function App() {
  return (<Router>
    <div className="App">
      <header className="App-header">
        <Navbar bg="success" variant="success">
          <Container>

            <Navbar.Brand>
              <Link to={"/create-hotel"} className="nav-link">
              Hotel manager
              </Link>
            </Navbar.Brand>

            <Nav className="justify-content-end">
              <Nav>
                <Link to={"/create-hotel"} className="nav-link">
                  Create Hotel
                </Link>
                <Link to={"/hotel-listing"} className="nav-link">
                  Hotels List
                </Link>
              </Nav>
            </Nav>

          </Container>
        </Navbar>
      </header>

      <Container>
        <Row>
          <Col md={12}>
            <div className="wrapper">
              <Switch>
                <Route exact path='/' component={CreateHotel} />
                <Route path="/create-hotel" component={CreateHotel} />
                <Route path="/edit-hotel/:id" component={EditHotel} />
                <Route path="/hotel-listing" component={HotelList} />
                <Route exact path='/login' component={Login} />
              </Switch>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  </Router>);
}

export default App;