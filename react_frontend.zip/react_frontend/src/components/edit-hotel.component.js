import React, { Component } from "react";
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import Swal from 'sweetalert2';

export default class EditHotel extends Component {

  constructor(props) {
    super(props)

    this.onChangeHotelName = this.onChangeHotelName.bind(this);
    this.onChangeHotelPrice = this.onChangeHotelPrice.bind(this);
    this.onChangeHotelDuration = this.onChangeHotelDuration.bind(this);
    this.onChangeHotelValidFrom = this.onChangeHotelValidFrom.bind(this);
    this.onChangeHotelValidTo = this.onChangeHotelValidTo.bind(this);
    this.onChangeHotelDescription = this.onChangeHotelDescription.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    // State
    this.state = {
      name: '',
      price: '',
      duration: '',
      valid_from: '',
      valid_to: '',
      description: ''
    }
  }

  componentDidMount() {
    axios.get('http://localhost:8000/api/hotel/'+ this.props.match.params.id, { 
      headers: { 
        'Authorization' : 'Bearer bFJ3QjlzNjJHZDZrdTBGZm93Nm9MVlRLQTZZRzd3d0g1TWMwQ1NObA=='
        }, 
      })
      .then(res => {
        // console.log(res.data[0]['name']);
        this.setState({
          name: res.data[0]['name'],
          price: res.data[0]['price'],
          valid_from: res.data[0]['valid_from'],
          valid_to: res.data[0]['valid_to'],
          duration: res.data[0]['duration'],
          description: res.data[0]['description']
        });
      })
      .catch((error) => {
        Swal.fire(
          error
        )
      })
  }

  onChangeHotelName(e) {
    this.setState({name: e.target.value})
  }

  onChangeHotelPrice(e) {
    this.setState({price: e.target.value})
  }

  onChangeHotelDuration(e) {
    this.setState({duration: e.target.value})
  }

  onChangeHotelValidFrom(e) {
    this.setState({valid_from: e.target.value})
  }

  onChangeHotelValidTo(e) {
    this.setState({valid_to: e.target.value})
  }

  onChangeHotelDescription(e) {
    this.setState({description: e.target.value})
  }

  onSubmit(e) {
    e.preventDefault()

    const hotelObject = {
      name: this.state.name,
      price: this.state.price,
      duration: this.state.duration,
      valid_from: this.state.valid_from,
      valid_to: this.state.valid_to,
      description: this.state.description
    };
    axios.put('http://localhost:8000/api/hotel/'+ this.props.match.params.id, hotelObject, { 
      headers: { 
        'Authorization' : 'Bearer bFJ3QjlzNjJHZDZrdTBGZm93Nm9MVlRLQTZZRzd3d0g1TWMwQ1NObA=='
        }, 
      })
      .then((res) => {
        Swal.fire(
          res.data.success,
          res.data.msg,
          'success'
        )
      }).catch((error) => {
        Swal.fire(
          error
        )
      })

    // Redirect to Hotel List 
    this.props.history.push('/hotel-listing');
  }


  render() {
    return (<div className="form-wrapper">
      <Form onSubmit={this.onSubmit}>
        <Form.Group controlId="name">
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" value={this.state.name} onChange={this.onChangeHotelName}/>
        </Form.Group>
      
        <Form.Group controlId="price">
          <Form.Label>Price</Form.Label>
                  <Form.Control type="number" value={this.state.price} onChange={this.onChangeHotelPrice}/>
        </Form.Group>
      
        <Form.Group controlId="valid_from">
          <Form.Label>Valid From</Form.Label>
          <Form.Control type="text" value={this.state.valid_from} onChange={this.onChangeHotelValidFrom}/>
        </Form.Group>
      
        <Form.Group controlId="valid_to">
          <Form.Label>Valid To</Form.Label>
                  <Form.Control type="text" value={this.state.valid_to} onChange={this.onChangeHotelValidTo}/>
        </Form.Group>  

        <Form.Group controlId="duration">
          <Form.Label>Duration</Form.Label>
                <Form.Control  type="text" value={this.state.duration} onChange={this.onChangeHotelDuration}/>
        </Form.Group>
            
        <Form.Group controlId="description">
          <Form.Label>Description</Form.Label>
                <Form.Control as="textarea" type="textarea" value={this.state.description} onChange={this.onChangeHotelDescription}/>
        </Form.Group>

        <Button variant="danger" size="lg" block="block" type="submit">
          Update Hotel
        </Button>
      </Form>
    </div>);
  }
}