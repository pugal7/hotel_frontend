import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import Swal from 'sweetalert2';

export default class HotelTableRow extends Component {
    constructor(props) {
        super(props);
        this.deleteHotel = this.deleteHotel.bind(this);
    }

    deleteHotel() {
        axios.delete('http://localhost:8000/api/hotel/'+ this.props.obj.id, { 
            headers: { 
            'Authorization' : 'Bearer bFJ3QjlzNjJHZDZrdTBGZm93Nm9MVlRLQTZZRzd3d0g1TWMwQ1NObA=='
            }, 
        })
        .then((res) => {
            Swal.fire(
                'Hotel deleted successfully'
              )
        }).catch((error) => {
            Swal.fire(
                error
              )
        })
    // Redirect to Hotel List 
    window.location("/");
    }
    render() {
        return (
            <tr>
                <td>{this.props.obj.name}</td>
                <td>{this.props.obj.price}</td>
                <td>{this.props.obj.duration}</td>
                <td>{this.props.obj.valid_from}</td>
                <td>{this.props.obj.valid_to}</td>
                <td>{this.props.obj.description}</td>
                <td>
                    <Link className="edit-link" to={"/edit-hotel/" + this.props.obj.id}>
                       <Button size="sm" variant="info">Edit</Button>
                    </Link>
                    <Button onClick={this.deleteHotel} size="sm" variant="danger">Delete</Button>
                </td>
            </tr>
        );
    }
}