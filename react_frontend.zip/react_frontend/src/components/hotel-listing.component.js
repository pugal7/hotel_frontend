import React, { Component } from "react";
import axios from 'axios';
import Table from 'react-bootstrap/Table';
import HotelTableRow from './HotelTableRow';
import Swal from 'sweetalert2';


export default class HotelList extends Component {

  constructor(props) {
    super(props)
    this.state = {
      hotel: []
    };
  }

  componentDidMount() {
    axios.get('http://localhost:8000/api/hotel/', { 
      
      headers: { 
        'Authorization' : 'Bearer bFJ3QjlzNjJHZDZrdTBGZm93Nm9MVlRLQTZZRzd3d0g1TWMwQ1NObA=='
        }, 
      })
      .then(res => {
        this.setState({
          hotel: res.data.data
        });
      })
      .catch((error) => {
        Swal.fire(
          error
        )
      })
  }

  DataTable() {
    return this.state.hotel.map((res, i) => {
      return <HotelTableRow obj={res} key={i} />;
    });
  }


  render() {
    return (<div className="table-wrapper">
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Duration</th>
            <th>Valid from</th>
            <th>Valid To</th>
            <th>Description</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {this.DataTable()}
        </tbody>
      </Table>
    </div>);
  }
}