import React, { Component } from "react";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from 'axios'
import HotelList from './hotel-listing.component';
import Swal from 'sweetalert2';


export default class CreateHotel extends Component {
      constructor(props) {
    super(props)

    // Setting up functions
    this.onChangeHotelName = this.onChangeHotelName.bind(this);
    this.onChangeHotelPrice = this.onChangeHotelPrice.bind(this);
    this.onChangeHotelDuration = this.onChangeHotelDuration.bind(this);
    this.onChangeHotelValidFrom = this.onChangeHotelValidFrom.bind(this);
    this.onChangeHotelValidTo = this.onChangeHotelValidTo.bind(this);
    this.onChangeHotelDescription = this.onChangeHotelDescription.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    // Setting up state
    this.state = {
      name: '',
      price: '',
      duration: '',
      valid_from: '',
      valid_to: '',
      description: ''
    }
  }

  onChangeHotelName(e) {
    this.setState({name: e.target.value})
  }

  onChangeHotelPrice(e) {
    this.setState({price: e.target.value})
  }

  onChangeHotelDuration(e) {
    this.setState({duration: e.target.value})
  }

  onChangeHotelValidFrom(e) {
    this.setState({valid_from: e.target.value})
  }

  onChangeHotelValidTo(e) {
    this.setState({valid_to: e.target.value})
  }

  onChangeHotelDescription(e) {
    this.setState({description: e.target.value})
  }

  onSubmit(e) {
    e.preventDefault()
     const hotel = {
      name: this.state.name,
      price: this.state.price,
      duration: this.state.duration,
      valid_from: this.state.valid_from,
      valid_to: this.state.valid_to,
      description: this.state.description
    };
    axios.post('http://localhost:8000/api/hotel/',hotel, { 
      
      headers: { 
        'Authorization' : 'Bearer bFJ3QjlzNjJHZDZrdTBGZm93Nm9MVlRLQTZZRzd3d0g1TWMwQ1NObA=='
        }, 
      })
      .then((res) => {
        console.log(res.data.success);
        Swal.fire(
          'Alert!',
          res.data.msg,
          res.data.success
        )
        if(res.data.success=="success"){
          window.location.reload(true);
        }
      }).catch((error) => {
        Swal.fire(
          error
        )
      })
  }

  render() {
    return (<div className="form-wrapper">
      <Form onSubmit={this.onSubmit}>
        <Row> 
            <Col>
             <Form.Group controlId="name">
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" value={this.state.name} onChange={this.onChangeHotelName}/>
             </Form.Group>
            
            </Col>
            
            <Col>
             <Form.Group controlId="price">
                <Form.Label>Price</Form.Label>
                        <Form.Control type="number" value={this.state.price} onChange={this.onChangeHotelPrice}/>
             </Form.Group>
            </Col>  
           
        </Row>

        <Row> 
            <Col>
             <Form.Group controlId="valid_from">
                <Form.Label>Valid From</Form.Label>
                <Form.Control type="text" value={this.state.valid_from} onChange={this.onChangeHotelValidFrom}/>
             </Form.Group>
            
            </Col>
            
            <Col>
             <Form.Group controlId="valid_to">
                <Form.Label>Valid To</Form.Label>
                        <Form.Control type="text" value={this.state.valid_to} onChange={this.onChangeHotelValidTo}/>
             </Form.Group>
            </Col>  
           
        </Row>

        <Form.Group controlId="duration">
          <Form.Label>Duration</Form.Label>
                <Form.Control  type="text" value={this.state.duration} onChange={this.onChangeHotelDuration}/>
        </Form.Group>
            

        <Form.Group controlId="description">
          <Form.Label>Description</Form.Label>
                <Form.Control as="textarea" type="textarea" value={this.state.description} onChange={this.onChangeHotelDescription}/>
        </Form.Group>

       
        <Button variant="primary" size="lg" block="block" type="submit">
          Add Hotel
        </Button>
      </Form>
      <br></br>
      <br></br>

      <HotelList> </HotelList>
    </div>);
  }
}




